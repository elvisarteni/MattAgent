"""Vero Status: a small dashboard that shows whether Vero is available and which model it uses."""

__version__ = "4.1.0"
APP_ID = "vero-status"
